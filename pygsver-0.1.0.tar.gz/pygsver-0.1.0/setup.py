#!/usr/bin/env python
#   -*- coding: utf-8 -*-

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'pygsver',
        version = '0.1.0',
        description = 'A Python script that manages semantic versioning of a git repository',
        long_description = "## py-git-semver\n[![coverage](https://img.shields.io/badge/coverage-100.0%25-brightgreen)](https://pybuilder.io/)\n[![complexity](https://img.shields.io/badge/complexity-Simple:%205-brightgreen)](https://radon.readthedocs.io/en/latest/api.html#module-radon.complexity)\n[![vulnerabilities](https://img.shields.io/badge/vulnerabilities-None-brightgreen)](https://pypi.org/project/bandit/)\n[![python](https://img.shields.io/badge/python-3.9-teal)](https://www.python.org/downloads/)\n\nA Python script that manages semantic versioning of a git repository. This is a port of [git-semver](https://github.com/edgexfoundry/git-semver) to Python.\n\nThe script leverages the following Python modules/libraries:\n* [GitPython](https://pypi.org/project/GitPython/) A Python library used to interact with Git repositories.\n* [semver](https://pypi.org/project/semver/) A Python module for semantic versioning.\n\n#### Motivation\n* conform to a scripting language that aligns better with current DevOps skillset\n* because `git semver` is a key DevOps capability it **must** be implemented using best-known software development practices:\n  * ensure a high-degree of unit test coverage\n  * ensure code complexity is low to facilitate quick rampup of new DevOps team members\n  * ensure it is free from common security issues\n  * maintain a thoroughly documented API\n  * include a robust build pipeline to continuously ensure code quality standards are maintained on every commit\n  * maintain a high-degree of developer confidence to facilitate future development or code refactoring\n* provide opportunity to migrate complexities from current `edgeXSemver` Jenkins Shared Library\n\n#### Remaining Effort\n* ensure 100% backwards compatability with:\n  * current Golang-based git-semver command line arguments\n  * current environment variable API\n* execute extensive functional testing\n  * build pipelines\n  * release pipelines\n\n\n## Development\n\nBuild image:\n```\ndocker image build \\\n  --target build-image \\\n  --build-arg http_proxy \\\n  --build-arg https_proxy \\\n  -t \\\n  pygsver:latest .\n```\n\nRun container:\n```\ndocker container run \\\n  --rm \\\n  -it \\\n  -e http_proxy \\\n  -e https_proxy \\\n  -v $PWD:/code \\\n  pygsver:latest \\\n  /bin/bash\n```\n\nExecute build:\n```\npyb -X\n```\n\n## Execution\nThe primary way that `git-semver` is consumed within a Jenkins Pipeline is via the [edgex-global-pipelines](https://github.com/edgexfoundry/edgex-global-pipelines) `edgeXSemver` function.  The steps to execute locally are described here for testing purposes only.\n\nBuild the local `pygsver` Docker image:\n```\ndocker image build \\\n  --build-arg http_proxy \\\n  --build-arg https_proxy \\\n  -t \\\n  pygsver:latest .\n```\n\nClone the repository you wish to version into your current working directory and cd into it; in the example below it is bind mounted to `repo` in the container.\n\nRun container from `pygsver` image - requires host to have a valid github ssh key - if behind proxy ensure the specified proxies are provided, the proxies can be discarded if not running behind a proxy:\n```\ndocker container run \\\n  --rm \\\n  -it \\\n  -e ALL_PROXY=[SOCKS_PROXY]  \\\n  -e http_proxy \\\n  -e https_proxy \\\n  -e LOCAL_UID=$(id -u $USER) \\\n  -e LOCAL_GID=$(id -g $USER) \\\n  -v $PWD:/repo \\\n  -v $HOME/.ssh:/home/user/.ssh \\\n  pygsver:latest \\\n  bash\n```\n\nVerify SSH inside the container:\n```\neval `ssh-agent`\nssh-add\nssh -T git@github.com\n```\n\nTypical execution flow:\n```\nexport SEMVER_PRE_PREFIX=dev\ngit semver init --version=0.1.0-dev.1\ngit semver tag\ngit semver bump pre\ngit semver push\ngit semver\n```\n\n## CLI Usage\n\n### `git semver`\n```\nusage: git-semver [-h] {init,tag,bump,push} ...\n\nA Python script that manages semantic versioning of a git repository\n\npositional arguments:\n  {init,tag,bump,push}\n    init                set the initial semantic version\n    tag                 create tag at HEAD of the current branch with the current semantic version prefixed with 'v'\n    bump                increment the current semantic version\n    push                push the semver branch commits and all version tags set on the current branch to the remote\n\noptional arguments:\n  -h, --help            show this help message and exit\n```\n\n### `git semver init`\n```\nusage: git-semver init [-h] [--version VERSION] [--force]\n  set the initial semantic version\n\noptional arguments:\n  -h, --help         show this help message and exit\n  --version VERSION  a specific semantic version to set as the initial\n  --force            force set the semantic version - required if a semantic version is already set\n```\n\n### `git semver tag`\n```\nusage: git-semver tag [-h] [--force]\n  create tag at HEAD of the current branch with the current semantic version prefixed with 'v'\n\noptional arguments:\n  -h, --help  show this help message and exit\n  --force     force set the tag - required if HEAD on the current branch is already tagged\n```\n\n### `git semver bump`\n```\nusage: git-semver bump [-h] {major,minor,patch,final,pre} ...\n  increment the current semantic version\n\npositional arguments:\n  {major,minor,patch,final,pre}\n    major               increment the MAJOR version\n    minor               increment the MINOR version\n    patch               increment the PATCH version\n    final               increment the FINAL version\n    pre                 increment the PRERELEASE version\n\noptional arguments:\n  -h, --help            show this help message and exit\n```\n\n### `git semver bump pre`\n```\nusage: git-semver bump pre [-h] [--prefix PREFIX]\n  increment the PRERELEASE version\n\noptional arguments:\n  -h, --help       show this help message and exit\n  --prefix PREFIX  specify the PRERELEASE prefix\n```\n\n### `git semver push`\n```\nusage: git-semver push [-h]\n  push the semver branch commits and all version tags set on the current branch to the remote\n\noptional arguments:\n  -h, --help  show this help message and exit\n```\n",
        long_description_content_type = 'text/markdown',
        classifiers = [
            'Development Status :: 4 - Beta',
            'Environment :: Console',
            'Environment :: Other Environment',
            'Intended Audience :: Developers',
            'Intended Audience :: System Administrators',
            'License :: OSI Approved :: Apache Software License',
            'Operating System :: POSIX :: Linux',
            'Programming Language :: Python',
            'Programming Language :: Python :: 3.6',
            'Programming Language :: Python :: 3.7',
            'Programming Language :: Python :: 3.8',
            'Programming Language :: Python :: 3.9',
            'Topic :: Software Development :: Libraries',
            'Topic :: Software Development :: Libraries :: Python Modules',
            'Topic :: System :: Networking',
            'Topic :: System :: Systems Administration'
        ],
        keywords = '',

        author = 'Emilio Reyes',
        author_email = 'emilio.reyes@intel.com',
        maintainer = '',
        maintainer_email = '',

        license = 'Apache License, Version 2.0',

        url = 'https://github.com/soda480/py-git-semver',
        project_urls = {},

        scripts = [],
        packages = ['pygsver'],
        namespace_packages = [],
        py_modules = [],
        entry_points = {
            'console_scripts': ['git-semver = pygsver.cli:main']
        },
        data_files = [],
        package_data = {},
        install_requires = [
            'semver',
            'GitPython'
        ],
        dependency_links = [],
        zip_safe = True,
        cmdclass = {'install': install},
        python_requires = '',
        obsoletes = [],
    )
